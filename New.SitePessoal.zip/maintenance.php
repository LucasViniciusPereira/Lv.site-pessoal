<!DOCTYPE HTML>
<html lang="pt-br">
<head>

    <meta charset="UTF-8">
<title>Página em Manutenção</title>
</head>
<body style="background:#FCFCFC">
	<center>
		<h1>Site em manutenção... </h1>
		<h3>
		Estamos em manutenção para melhorar nosso serviço</br>
		Tente novamente mais tarde.
		</h3>
	</center>
</body>
</html>